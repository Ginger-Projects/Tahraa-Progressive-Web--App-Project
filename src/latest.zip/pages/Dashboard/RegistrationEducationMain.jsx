import React from "react";
import RegistrationEducation from "../../components/Dashbaord/RegistrationEducation";

const RegistrationEducationMain = () => {
  return <RegistrationEducation />;
};

export default RegistrationEducationMain;
