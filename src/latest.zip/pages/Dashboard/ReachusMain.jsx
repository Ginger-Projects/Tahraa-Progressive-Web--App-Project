import React from "react";
import Reachus from "../../components/Dashbaord/Reachus";

const ReachusMain = () => {
  return <Reachus />;
};

export default ReachusMain;
