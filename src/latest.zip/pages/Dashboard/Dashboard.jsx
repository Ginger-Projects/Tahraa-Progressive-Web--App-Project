import React from "react";
import ExpertsPage from "./ExpertsPage";

const Dashboard = () => {
  return (
    <>
      <ExpertsPage />
    </>
  );
};

export default Dashboard;
