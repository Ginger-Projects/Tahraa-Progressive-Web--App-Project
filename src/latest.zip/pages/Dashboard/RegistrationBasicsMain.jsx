import React from "react";
import RegistrationBasics from "../../components/Dashbaord/RegistrationBasics";

const RegistrationBasicsMain = () => {
  return <RegistrationBasics />;
};

export default RegistrationBasicsMain;
