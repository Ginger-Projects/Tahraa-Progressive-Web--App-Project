import React from "react";
import RegistrationWork from "../../components/Dashbaord/RegistrationWork";

const RegistrationWorkMain = () => {
  return <RegistrationWork />;
};

export default RegistrationWorkMain;
