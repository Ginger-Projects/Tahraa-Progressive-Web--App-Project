import React from "react";
import HeroBanner from "../components/Home/HeroBanner";
import { Slider } from "../components/Home/Slider";
import { SliderTwo } from "../components/Home/SliderTwo";
import { SliderThree } from "../components/Home/SliderThree";
import { VideSection } from "../components/Home/VideSection";
import { SectionFour } from "../components/Home/SectionFour";
import { Footer } from "../components/Home/Footer";


export const Home = () => {
  return (
    <>
    <HeroBanner />
    <Slider />
    <SliderTwo />
    <SliderThree />
    <VideSection />
    <SectionFour />
    <Footer />
    <div className="whatsapp-float">
      <a
        href="https://wa.me/1234567890"
        target="_blank"
        rel="noopener noreferrer"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="72" height="72" viewBox="0 0 72 72" fill="none">
          <g clipPath="url(#clip0_178_1782)">
            <path d="M61.56 10.347C54.72 3.735 45.72 0 36.135 0C8.625 0 -8.649 29.805 5.088 53.514L0 72L19.005 67.044C27.285 71.517 34.068 71.121 36.153 71.385C68.052 71.385 83.931 32.793 61.515 10.464L61.56 10.347Z" fill="#ECEFF1"/>
            <path d="M36.201 65.2531L36.183 65.2501H36.135C26.589 65.2501 20.49 60.7291 19.89 60.4681L8.64001 63.3932L11.655 52.4581L10.938 51.3331C7.96801 46.6051 6.39001 41.1601 6.39001 35.5531C6.39001 9.17415 38.625 -4.01685 57.279 14.6281C75.888 33.0781 62.823 65.2531 36.201 65.2531Z" fill="#4CAF50"/>
            <path d="M52.521 42.921L52.494 43.146C51.591 42.696 47.193 40.545 46.374 40.248C44.535 39.567 45.054 40.14 41.523 44.184C40.998 44.769 40.476 44.814 39.585 44.409C38.685 43.959 35.796 43.014 32.376 39.954C29.712 37.569 27.924 34.644 27.396 33.744C26.517 32.226 28.356 32.01 30.03 28.842C30.33 28.212 30.177 27.717 29.955 27.27C29.73 26.82 27.939 22.41 27.189 20.652C26.469 18.9 25.728 19.122 25.173 19.122C23.445 18.972 22.182 18.996 21.069 20.154C16.227 25.476 17.448 30.966 21.591 36.804C29.733 47.46 34.071 49.422 42.003 52.146C44.145 52.827 46.098 52.731 47.643 52.509C49.365 52.236 52.944 50.346 53.691 48.231C54.456 46.116 54.456 44.361 54.231 43.956C54.009 43.551 53.421 43.326 52.521 42.921Z" fill="#FAFAFA"/>
          </g>
          <defs>
            <clipPath id="clip0_178_1782">
              <rect width="72" height="72" fill="white"/>
            </clipPath>
          </defs>
        </svg>
      </a>
    </div>
    </>
  );
};
